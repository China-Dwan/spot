create
    definer = root@`%` function GET_RANDOM(start_ decimal(10, 2), end_ decimal(10, 2)) returns decimal(10, 2)
begin
	declare random DECIMAL(10,2) DEFAULT 0 ; 
	while (random < start_ or random > end_) do
	set random = round((rand()+1),2);
	end while;
	return random;
end;

