create
    definer = root@`%` procedure PRO_SYNC_JD_GOODS_CLASS()
BEGIN

SET @tempFlg1 = '1temp' + CURRENT_DATE ();


SET @tempFlg2 = '2temp' + CURRENT_DATE ();


SET @tempFlg3 = '3temp' + CURRENT_DATE ();


SET SESSION sql_mode = '';

--  将不存在的一级分类插入到goodsClass表中
INSERT INTO shop_goods_class (
	gc_id,
	gc_name,
	type_id,
	type_name,
	gc_parent_id,
	gc_sort,
	gc_show,
	gc_idpath,
	gc_keywords,
	gc_description
) SELECT
	@tempId := REPLACE (uuid(), '-', ""),
	a. NAME,
	@tempId,
	a. NAME,
	0,
	0,
	1,
	CONCAT(@tempId, ","),
	@tempFlg1,
	a.cat_id
FROM
	jd_goods_categorys a
LEFT JOIN shop_goods_class b ON a.own_cat_id = b.gc_id
WHERE
	a.cat_class = 0
AND b.gc_id IS NULL;

UPDATE shop_goods_class
SET type_id = gc_id,
 gc_idpath = CONCAT(gc_id, ",")
WHERE
	gc_keywords = @tempFlg1;



-- 将 数据更新回jd 表 gcID
UPDATE jd_goods_categorys a,
 shop_goods_class b
SET a.own_cat_id = b.gc_id,
 a.own_parent_cat_id = 0,
 a.own_top_cat_id = b.gc_id
WHERE
	b.gc_description = a.cat_id
AND a.cat_class = 0
AND b.gc_keywords = @tempFlg1;

-- jd 表中的自有二级分类更新为一级分类的最新ID
UPDATE jd_goods_categorys a,
 jd_goods_categorys b
SET b.own_parent_cat_id = a.own_cat_id,
 b.own_top_cat_id = a.own_cat_id,
 b.own_enabled = 2
WHERE
	b.cat_class = 1
AND a.cat_id = b.parent_cat_id
AND a.cat_class = 0
AND b.cat_id IN (
	SELECT
		t.cat_id
	FROM
		(
			SELECT
				*
			FROM
				jd_goods_categorys a
			LEFT JOIN shop_goods_class b ON a.own_cat_id = b.gc_id
			WHERE
				b.gc_id IS NULL
			AND a.cat_class = 1
		) t
);

INSERT INTO shop_goods_class (
	gc_id,
	gc_name,
	type_id,
	type_name,
	gc_parent_id,
	gc_sort,
	gc_show,
	gc_idpath,
	gc_keywords,
	gc_description
) SELECT
	@tempId := REPLACE (uuid(), '-', ""),
	b. NAME,
	a.own_cat_id,
	a. NAME,
	a.own_cat_id,
	0,
	1,
	CONCAT(
		a.own_cat_id,
		"," ,@tempId,
		","
	),
	@tempFlg2,
	b.cat_id
FROM
	jd_goods_categorys a
LEFT JOIN jd_goods_categorys b ON a.cat_id = b.parent_cat_id
WHERE
	b.cat_id IN (
		SELECT
			t.cat_id
		FROM
			(
				SELECT
					*
				FROM
					jd_goods_categorys a
				LEFT JOIN shop_goods_class b ON a.own_cat_id = b.gc_id
				WHERE
					b.gc_id IS NULL
				AND a.cat_class = 1
			) t
	);

UPDATE shop_goods_class
SET gc_idpath = CONCAT(type_id, ",", gc_id, ",") --  select * from shop_goods_class
WHERE
	gc_keywords = @tempFlg2;

-- 将shop_godos表的id 更新回jd表
UPDATE jd_goods_categorys a,
 shop_goods_class b
SET a.own_cat_id = b.gc_id
WHERE
	a.cat_id = b.gc_description
AND b.gc_keywords = @tempFlg2
AND a.cat_class = 1;

-- jd 表中的自有三级分类更新为一级,二级分类的最新ID   3145
UPDATE jd_goods_categorys a,
 jd_goods_categorys b,
 jd_goods_categorys c
SET c.own_parent_cat_id = b.own_cat_id,
 c.own_top_cat_id = a.own_cat_id,
 c.own_enabled = 2
WHERE
	c.cat_class = 2
AND b.cat_class = 1
AND a.cat_class = 0
AND a.cat_id = b.parent_cat_id
AND b.cat_id = c.parent_cat_id
AND c.cat_id IN (
	SELECT
		t.cat_id
	FROM
		(
			SELECT
				*
			FROM
				jd_goods_categorys a
			LEFT JOIN shop_goods_class b ON a.own_cat_id = b.gc_id
			WHERE
				b.gc_id IS NULL
			AND a.cat_class = 2
		) t
);

INSERT INTO shop_goods_class (
	gc_id,
	gc_name,
	type_id,
	type_name,
	gc_parent_id,
	gc_sort,
	gc_show,
	gc_idpath,
	gc_keywords,
	gc_description
) SELECT
	@tempId := REPLACE (uuid(), '-', ""),
	c. NAME,
	a.own_cat_id,
	a. NAME,
	b.own_cat_id,
	0,
	1,
	CONCAT(
		a.own_cat_id,
		",",
		b.own_cat_id,
		"," ,@tempId,
		","
	),
	@tempFlg3,
	c.cat_id
FROM
	jd_goods_categorys a
LEFT JOIN jd_goods_categorys b ON a.cat_id = b.parent_cat_id
LEFT JOIN jd_goods_categorys c ON b.cat_id = c.parent_cat_id
WHERE
	a.cat_class = 0
AND b.cat_class = 1
AND c.cat_class = 2
AND c.cat_id IN (
	SELECT
		t.cat_id
	FROM
		(
			SELECT
				*
			FROM
				jd_goods_categorys a
			LEFT JOIN shop_goods_class b ON a.own_cat_id = b.gc_id
			WHERE
				b.gc_id IS NULL
			AND a.cat_class = 2
		) t
);

UPDATE shop_goods_class
SET gc_idpath = CONCAT(
	type_id,
	",",
	gc_parent_id,
	",",
	gc_id,
	","
) --  select * from shop_goods_class
WHERE
	gc_keywords = @tempFlg3;

-- 将shop_godos表的id 更新回jd表
UPDATE jd_goods_categorys a,
 shop_goods_class b
SET a.own_cat_id = b.gc_id
WHERE
	a.cat_id = b.gc_description
AND b.gc_keywords = @tempFlg3
AND a.cat_class = 2;

UPDATE jd_goods_categorys
SET own_enabled = 0;

UPDATE jd_goods_categorys
SET own_enabled = 1
WHERE
	id IN (
		SELECT
			t.id
		FROM
			(
				SELECT
					a.id
				FROM
					jd_goods_categorys a
				WHERE
					a.cat_class = 0
				AND a.`name` IN (
					'个人护理',
					'农资绿植',
					'办公用品',
					'医药保健',
					'厨具',
					'处方药',
					'宠物生活',
					'家具',
					'家具家装',
					'家居日用',
					'家庭清洁/纸品',
					'家用电器',
					'家纺',
					'家装建材',
					'工业品',
					'手机',
					'数码',
					'数码产品',
					'日用百货',
					'服饰内衣',
					'本地生活/旅游出行',
					'母婴',
					'汽车用品',
					'玩具乐器',
					'生活用品',
					'生鲜',
					'电脑、办公',
					'电脑产品',
					'电脑附件',
					'礼品箱包',
					'箱包皮具',
					'美妆个护',
					'运动户外',
					'酒类',
					'钟表',
					'鞋靴',
					'食品饮料'
				)
				UNION
					SELECT
						b.id
					FROM
						jd_goods_categorys a
					LEFT JOIN jd_goods_categorys b ON a.cat_id = b.parent_cat_id
					WHERE
						a.cat_class = 0
					AND a. NAME IN (
						'个人护理',
						'农资绿植',
						'办公用品',
						'医药保健',
						'厨具',
						'处方药',
						'宠物生活',
						'家具',
						'家具家装',
						'家居日用',
						'家庭清洁/纸品',
						'家用电器',
						'家纺',
						'家装建材',
						'工业品',
						'手机',
						'数码',
						'数码产品',
						'日用百货',
						'服饰内衣',
						'本地生活/旅游出行',
						'母婴',
						'汽车用品',
						'玩具乐器',
						'生活用品',
						'生鲜',
						'电脑、办公',
						'电脑产品',
						'电脑附件',
						'礼品箱包',
						'箱包皮具',
						'美妆个护',
						'运动户外',
						'酒类',
						'钟表',
						'鞋靴',
						'食品饮料'
					)
					UNION
						SELECT
							c.id
						FROM
							jd_goods_categorys a
						LEFT JOIN jd_goods_categorys b ON a.cat_id = b.parent_cat_id
						LEFT JOIN jd_goods_categorys c ON b.cat_id = c.parent_cat_id
						WHERE
							a.cat_class = 0
						AND a. NAME IN (
							'个人护理',
							'农资绿植',
							'办公用品',
							'医药保健',
							'厨具',
							'处方药',
							'宠物生活',
							'家具',
							'家具家装',
							'家居日用',
							'家庭清洁/纸品',
							'家用电器',
							'家纺',
							'家装建材',
							'工业品',
							'手机',
							'数码',
							'数码产品',
							'日用百货',
							'服饰内衣',
							'本地生活/旅游出行',
							'母婴',
							'汽车用品',
							'玩具乐器',
							'生活用品',
							'生鲜',
							'电脑、办公',
							'电脑产品',
							'电脑附件',
							'礼品箱包',
							'箱包皮具',
							'美妆个护',
							'运动户外',
							'酒类',
							'钟表',
							'鞋靴',
							'食品饮料'
						)
			) t
	);


END;

