create
    definer = root@`%` function CREATE_JD_UUID(length_ smallint(6), prefix varchar(10)) returns varchar(20)
BEGIN
        DECLARE jd_goods_id VARCHAR(20) DEFAULT '';
        IF @jd_goods_id_num >= 0 
            THEN set @jd_goods_id_num = @jd_goods_id_num + 1;
        ELSE
            set @jd_goods_id_num = 0;
        END IF;
        WHILE (LENGTH(jd_goods_id) + LENGTH(@jd_goods_id_num)) < ( length_ - LENGTH(prefix)) DO
            set jd_goods_id = CONCAT(jd_goods_id , "0");
        END WHILE;
        set jd_goods_id = CONCAT(prefix , jd_goods_id,@jd_goods_id_num);
    RETURN jd_goods_id;
END;

